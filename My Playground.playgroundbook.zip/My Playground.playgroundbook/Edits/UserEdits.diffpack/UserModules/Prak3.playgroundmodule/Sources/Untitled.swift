
import UIKit
public class Main
{
    public init()
    {
        var autoDeeler : Deeler? = Deeler()
        var AvtoVaz = AutomobileFactory(delegate: autoDeeler);
        autoDeeler?.automobileFactory = AvtoVaz
        autoDeeler?.makeAnOrder(numberOfSedans: 2, numberOfTrucks: 3, numberOfSportcar: 4)
        var Lada = autoDeeler?.sellSedan()
        Lada?.ride()
        Lada?.upgradeSteer(steer: steerWooden)
    }
}

