
import UIKit
protocol Auto
{
    var engine : Engine? {get set}
    var steer : Steering? {get set}
    var wheels : [Wheel?] {get set}
    var working : Bool {get set}
    var zavod : AutomobileFactory? {get set}
    func ride()
    mutating func upgradeEngine(engine : Engine?)
    mutating func upgradeSteer(steer : Steering?)
    mutating func upgradeWheels(wheels : [Wheel?])
    init()
    init(engine : Engine?, steer : Steering?, wheels: [Wheel?], zavod: AutomobileFactory?, working : Bool)
    
}
extension Auto
{
    init(engine : Engine?, steer : Steering?, wheels: [Wheel?], zavod: AutomobileFactory?, working : Bool)
    {
        self.init()
        self.engine = engine;
        self.steer = steer
        self.wheels = wheels
        self.working = working;
        self.zavod = zavod;
    }   
    mutating func upgradeEngine(engine : Engine?)
    {
        self.engine = engine
    }
    mutating func upgradeSteer(steer : Steering?)
    {
        self.steer = steer
    }
    mutating func upgradeWheels(wheels : [Wheel?])
    {
        self.wheels = wheels
    }
    func ride()
    {
        print("WROOOM")
    }
}
class Sedan : Auto
{
    var engine: Engine? = nil
    var steer: Steering? = nil
    var wheels: [Wheel?] = []
    var zavod: AutomobileFactory? = nil
    var working : Bool = false
    required init() {} 
    func openRoof()
    {
        print("roof open")
    }
}
class Truck : Auto
{
    var engine: Engine? = nil
    var steer: Steering? = nil
    var wheels: [Wheel?] = []
    var zavod: AutomobileFactory? = nil
    var working : Bool = false
    required init() {} 
    func climb()
    {
        print("climb")
    }
}
class Sportcar : Auto
{
    var engine: Engine? = nil
    var steer: Steering? = nil
    var wheels: [Wheel?] = []
    var zavod: AutomobileFactory? = nil
    var working : Bool = false
    required init(){}
    func zoom()
    {
        print("vzooom");
    }
}

