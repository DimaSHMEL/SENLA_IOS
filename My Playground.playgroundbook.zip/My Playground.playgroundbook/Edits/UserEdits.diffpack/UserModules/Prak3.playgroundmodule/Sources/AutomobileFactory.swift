

import Foundation
class AutomobileFactory
{
    var delegate : AutomobileFactoryDelegate?
    init(delegate : AutomobileFactoryDelegate?){
        self.delegate = delegate
    }
    private func makeSedan() -> Sedan?
    {
        return Sedan(engine: v8EngineGas, steer: steerWooden, wheels: summerWheels, zavod: self, working: true);
    }
    private func makeTruck() -> Truck?
    {
        return Truck(engine: truckEngine, steer: steerMetal, wheels: summerWheels, zavod: self, working: true);
    }
    private func makeSportcar() -> Sportcar?
    {
        return Sportcar(engine: v16EngineGas, steer: steerMetal, wheels: summerWheels, zavod: self, working: true);
    }
    func makeAuto(type : Int, howMuch : Int)
    {
        var sedanBatch : [Sedan?] = []
        var truckBatch : [Truck?] = []
        var sportcarBatch : [Sportcar?] = []
        switch(type)
        {
        case 0:
            for _ in 1 ... howMuch {
                sedanBatch.append(makeSedan())
            }
            break
        case 1: 
            for _ in 1 ... howMuch {
                truckBatch.append(makeTruck())
            }
            break
        default:
            for _ in 1 ... howMuch {
                sportcarBatch.append(makeSportcar())
            }
            break
        }
        if sedanBatch.capacity != 0 || truckBatch.capacity != 0 || sportcarBatch.capacity != 0 {
            delegate?.batchWasMage((sedanBatch, truckBatch, sportcarBatch))
        }
    }
}
