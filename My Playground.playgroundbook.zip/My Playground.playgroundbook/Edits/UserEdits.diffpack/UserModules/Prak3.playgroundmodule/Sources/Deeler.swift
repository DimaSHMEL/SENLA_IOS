import UIKit
protocol AutomobileFactoryDelegate
{
    func batchWasMage(_ batch :  ([Sedan?], [Truck?], [Sportcar?]) )
    
}
class Deeler : AutomobileFactoryDelegate
{
    var storageSedan : [Sedan?] = []
    var storageTruck : [Truck?] = []
    var storageSportcar : [Sportcar?] = []
    var automobileFactory : AutomobileFactory? = nil
    func batchWasMage(_ batch: ([Sedan?], [Truck?], [Sportcar?])) {
        for i in batch.0
        {
            self.storageSedan.append(i)
            
        }
        if batch.0.count != 0
        {
            print(batch.0.count, " were added to the Sedan storage")
        }
        for i in batch.1
        {
            self.storageTruck.append(i)
        }
        if batch.1.count != 0
        {
        print(batch.1.count, " were added to the Truck storage")
        }
        for i in batch.2
        {
            self.storageSportcar.append(i)
        }
        if batch.2.count != 0
        {
            print(batch.2.count, " were added to the Sportcar storage")
        }
    }
    func makeAnOrder(numberOfSedans: Int, numberOfTrucks : Int, numberOfSportcar : Int)
    {
        automobileFactory?.makeAuto(type: 0, howMuch: numberOfSedans)
        automobileFactory?.makeAuto(type: 1, howMuch: numberOfTrucks)
        automobileFactory?.makeAuto(type: 2, howMuch: numberOfSportcar)
    }
    func sellSedan() -> Sedan?{
        if storageSedan.count != 0
        {
            let temp = storageSedan.remove(at: storageSedan.count - 1)
            return temp
        }
        return nil
    }
    func sellTruck() -> Truck?{
        if storageTruck.count != 0
        {
            let temp = storageTruck.remove(at: storageTruck.count - 1)
            return temp
        }
        return nil
    }
    func sellSportcar() -> Sportcar?{
        if storageSportcar.count != 0
        {
            let temp = storageSportcar.remove(at: storageSportcar.count - 1)
            return temp
        }
        return nil
    }
    
    
}
