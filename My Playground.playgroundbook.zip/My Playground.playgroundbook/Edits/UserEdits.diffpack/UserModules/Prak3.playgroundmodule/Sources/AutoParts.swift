import UIKit

let wheelSummer : Wheel? = Wheel(diametr: 20, tire: "Summer soft", disks: "Metal bright") 
let summerWheels = [wheelSummer, wheelSummer,wheelSummer,wheelSummer]
let wheelWinter : Wheel? = Wheel(diametr: 20, tire: "Winter rough", disks: "Metal bright")

let v8EngineGas : Engine? = Engine(expense: 100, name: "V8 strong engine", maxTurnOvers: 2500, cylinders: 8, type: "Town, gas")
let v8EngineElectro : Engine? = Engine(expense: 120, name: "V8 medium engine", maxTurnOvers: 3000, cylinders: 8, type: "Town, electro")
let v16EngineGas : Engine? = Engine(expense: 200, name: "V16 strong engine", maxTurnOvers: 4000, cylinders: 16, type: "Sport, Gas")
let truckEngine : Engine? = Engine(expense: 500, name: "BELAZ engine", maxTurnOvers: 15000, cylinders: 16, type: "Truck, Gas")

let steerWooden : Steering? = Steering(material: "Wood", diameter: 30, honk: "HONK HONK")
let steerMetal : Steering? = Steering(material: "Metal", diameter: 25, honk: "BRIN BRIN")
struct Engine
{
    var expense : Int
    var name : String
    var maxTurnOvers : Int
    var cylinders : Int
    var type : String
    init(expense : Int, name : String, maxTurnOvers : Int, cylinders : Int, type : String)
    {
        self.expense = expense
        self.name = name
        self.maxTurnOvers = maxTurnOvers
        self.cylinders = cylinders
        self.type = type
    }
}

struct Steering
{
    var material : String
    var diameter : Int
    var honk : String
    init(material : String, diameter : Int, honk : String)
    {
        self.diameter = diameter
        self.material = material
        self.honk = honk
    }
}

struct Wheel
{
    var diametr: Int
    var tire : String
    var disks : String
    init(diametr : Int, tire : String, disks : String)
    {
        self.disks = disks
        self.diametr = diametr
        self.tire = tire
    }
}
